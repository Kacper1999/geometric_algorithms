class Line:
    def __init__(self, a, b):
        self.a = a
        self.b = b
